import java.util.Scanner;
public class WhileLoops {


public static void main(String[] args) {
Scanner input = new Scanner(System.in);
{
	 System.out.println("Input an integer: ");
     final int n = 100;
     int counter = 0;


     while (counter*counter< n) {
     System.out.print(counter*counter + " ");
     counter++;
     int square = input.nextInt();
     //squares less than n.

}

     System.out.println("Input an integer:");
     counter = 1;
     while (counter < n) {
     if (counter % 10 == 0) {
     System.out.print(counter + " ");
     int positive = input.nextInt();
     //positive numbers divisible by 10 and less than n.
}
     counter++;




}
     System.out.println("Input an integer:");
     counter= 0;
     while (Math.pow(2, counter) < n) {
     System.out.print( (int) (Math.pow(2, counter))+" ");
     counter++;
     // powers of two less than n.



}
}
}
}
