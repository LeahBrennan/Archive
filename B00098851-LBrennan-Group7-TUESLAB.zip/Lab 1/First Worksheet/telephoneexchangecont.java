import java.util.Scanner;
public class telephoneexchangecont
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);

		int areacode;

				   System.out.println("Enter an area code: ");
				   areacode = input.nextInt();

				   if (areacode == 1){
					   System.out.println("Dublin");
				   }else if(areacode == 44){

					   System.out.println("Westmeath");
				   }else if(areacode == 21){

					   System.out.println("Cork");
				   }else if(areacode == 74){

					   System.out.println("Donegal");
				   }
			   }
  {
        int x = 0;

        do {
           System.out.print("value of x : " + x );
           x++;
           System.out.print("");
        }while( x >1 );
        {
			System.out.println("End of Program!");
		}
     }
}






