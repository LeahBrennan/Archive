import java.util.Scanner;
public class telephoneexchangeopp
{
       public static void main (String[] args)
       {

		   Scanner input = new Scanner(System.in);

	         System.out.println("Please enter a county:");
             String x = input.nextLine();

             getCodeForCounty(String);

}
             public static String getCodeforCounty(String county)
{

             switch(county){

				 case "Dublin": System.out.println("1");
				 break;


				 case "Cork": System.out.println("21");
				 break;

                 case "Westmeath": System.out.println("44");
                 break;

                 case "Donegal": System.out.println("74");
                 break;

                 default: System.out.println("That is incorrect, please try again");
                 break;

                 return county;

 }

}
}


