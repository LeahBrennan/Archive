import java.util.Scanner;

public class sequences 2 {
    public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	String adjacent_duplicates = "";
	System.out.print("Number: ");
	double input_number = input.nextDouble();
	double previous = input_number;
	boolean first_input = true;
	while (input.hasNextDouble()) {
	    System.out.print("Number: ");
	    input_number = input.nextDouble();
	    if (first_input != true && input_number == previous) {
		adjacent_duplicates += String.format("%s ", input_number);
	    }
	    first_input = false;
	    previous = input_number;
	}
	input.close();
	System.out.println(adjacent_duplicates);
    }
}