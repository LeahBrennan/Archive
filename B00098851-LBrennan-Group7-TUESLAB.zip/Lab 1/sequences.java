import java.util.Scanner;

public class sequences {

    public static void main(String[] args) {
		    Scanner in = new Scanner(System.in);
		    System.out.println("Enter a sequence of numbers then press enter:");

		    int even =in.nextInt();
		    int odd =in.nextInt();

            for(int counter = even% 2; odd = 1; counter++)



            System.out.println("Even numbers: " + even);
            System.out.println("Odd numbers: " + odd);



          int value = in.nextInt();
          int total = in.nextInt();
          int cumulative = in.nextInt();


          do
          {
              value = in.nextInt();

              cumulative= total + value;

              System.out.println("Your cumulative totals are " + total);
          }

          while ( value != 0 );





    }
}














