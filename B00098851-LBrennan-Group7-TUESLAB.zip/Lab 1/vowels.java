import java.util.Scanner;

public class vowels{

public static String Vowels ="aeiouAEIOU";

public static void main(String[] args){

        Scanner sc = new Scanner(System.in);


         System.out.println("Enter a word to count the vowels:" );
         String nm = sc.nextLine();
         int vowel= 0;

        for(int i=1;i<nm.length();i++){
            for(int j=1;j<Vowels.length();j++){
                if(Vowels.charAt(j)==nm.charAt(i)){
                    vowel++;
                    break;
                }
            }
        }

        System.out.println("Number of Vowels: " +vowel);
     }

}