import java.util.Scanner;

public class digits
{
  public static void main(String[]args)
  {
    int num;

    Scanner input = new Scanner(System.in);
    System.out.println("Enter any integer: ");
    num = input.nextInt();
    input.close();

    System.out.print(digits(num, num));

  }

  public static int digits(int x, int num)

  {
    if (num == 0)
    {return 1;}
    else if (x == 0)
    {return 0;}
    else
    {
      return 1 + digits(x/10, num);

  }

  }//end of method

}//end of class digits
