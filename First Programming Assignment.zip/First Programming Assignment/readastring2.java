import java.util.Scanner;
class readastring2 {
	Scanner input = new Scanner( System.in );
	String input;
          input = input.next( );
          String input;
		  System.out.print("Some random String: ");
          input= input.next( );
    String output;
    System.out.print("Some random String: ");
    output = output.next( );
String output;
System.out.println("You are " + full_name);








}
}