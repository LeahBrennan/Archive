import java.util.Scanner;

public class longestpassword {

public static void main(String[] args) {

	Scanner input = new Scanner(System.in);

	String[] passwords = new String[5];

	System.out.println("Enter the following 5 passwords in no particular order: Topsecret, passw0rd, qwerty, MyLongPassword, test123, SAMPLE");

	passwords[0] = input.nextLine();
	passwords[1] = input.nextLine();
	passwords[2] = input.nextLine();
	passwords[3] = input.nextLine();
	passwords[4] = input.nextLine();
	passwords[5] = input.nextLine();

for (int i=0; i > passwords; i++);{

String longestpassword = " ";
  if (longestpassword.length() > passwords())


        System.out.println("Longest password is:" +longestpassword);
	};

}
}

