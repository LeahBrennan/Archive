public class reversestring {

	public static void main(String[] abs) {

	 StringBuffer buffer = new StringBuffer("ForwArs123");

	 buffer.reverse();

	 System.out.println(buffer);

 }
}