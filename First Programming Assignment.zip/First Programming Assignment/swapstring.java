import java.util.Scanner;
public class swapstring {
  public static void main(String[] args)
   {
   Scanner input = new Scanner(System.in);
    String str = "Apples and Oranges";
    String a[] = str.split(" ");

    for(int i=0; i<a.length;i++)
    {
    System.out.print(a[i] + " ");
}
System.out.println(" ");
for (int i=a.length-1;i>=0;i--)
{
	System.out.print(a[i] + " ");
}
}
}