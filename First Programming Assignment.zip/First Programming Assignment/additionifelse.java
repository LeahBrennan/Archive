import java.util.Scanner;

public class additionifelse
{
	public static void main(String[] abs)
{
	Scanner input = new Scanner(System.in);

	int answera = 1234;
	int answerb = 21325;
	int sum;

	System.out.println("The sum of two numbers equals: twenty two thousand five hundred and fifty nine.");

    System.out.print("Enter the first possible integer: ");
    answera = input.nextInt();

    System.out.print("Enter the second possible integer: ");
    answerb = input.nextInt();

     if (answera > 1234) {
		 System.out.println("Incorrect"); }
	else{
		System.out.println("Please enter another integer: "); }
        if (answera == 1234){
			System.out.println("Correct!");}

	if (answerb > 21325) {
		System.out.println("Incorrect"); }
		else{
			System.out.println("Please enter another integer: "); }
			if (answerb == 21325) {
				System.out.println("Correct!"); }


}
}