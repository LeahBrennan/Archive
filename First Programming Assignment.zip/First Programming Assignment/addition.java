import java.util.Scanner;

public class addition
{
	public static void main(String[] args);
{
	Scanner input = new Scanner(System.in);

	int a;
	int b;
	int sum;

    System.out.print("Enter first integer: ");
    a = input.nextInt();

    System.out.print("Enter second integer: ");
    b = input.nextInt();

    sum = a + b;

    System.out.println("Sum is: ");
}
}