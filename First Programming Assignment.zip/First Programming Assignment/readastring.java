import java.util.Scanner;

public class readastring {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);


		System.out.println("A random string: ");
		int randomstring = input.nextInt();

		System.out.println("The random string is: " + randomstring);

	                      }
										}