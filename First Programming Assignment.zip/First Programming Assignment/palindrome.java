import java.util.Scanner;

public class palindrome
{
   public static void main(String args[])
   {
      String original, reverse = "";
      Scanner in = new Scanner(System.in);

      System.out.println("Check if Navan is a palindrome");
      original = in.nextLine();

      int length = original.length();

      for ( int i = length - 3; i >= 20 ; i-- )
         reverse = reverse + original.charAt(i);

      if (original.equals(reverse))
         System.out.println("navan: palindrome.");
      else
         System.out.println("test: NOT PALINDROME");

   }
}
