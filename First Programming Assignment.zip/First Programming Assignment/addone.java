import java.util.Scanner;

public class addone
{
	public static void main(String[] args)
{
	Scanner input = new Scanner(System.in);
	int answera = 8;
	int answerb = 113;
	int answerc = 1002;
	int sum;

	System.out.print("A+1= 9");
	{System.out.println("A+1=9"); }
	answera = input.nextInt();
  { System.out.println("A = 8");
}

	System.out.print("B+1=114"); {
	System.out.println("B+1=114"); }
	answerb = input.nextInt();
	{ System.out.println("B = 113");
}



	System.out.print("C+1=1003");
	{ System.out.println("C+1=1003"); }
	answerc = input.nextInt();
	{ System.out.println("C = 1002"); }

}
}

