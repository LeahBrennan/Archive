import java.util.Scanner;

public class average
{
	public static void main(String[] args)

	{
		Scanner sc = new Scanner(System.in);
		 {
			 System.out.println("Find the average of the following five numbers; ");
		 }
		System.out.println("Number 1: Six");
		double Number1 = sc.nextDouble();
		System.out.println("Number 2: One hundred and thirteen");
		double Number2 = sc.nextDouble();
		System.out.println("Number 3: Thirty-one");
		double Number3 = sc.nextDouble ();
		System.out.println("Number 4: Twenty-seven");
		double Number4 = sc.nextDouble ();
		System.out.println("Number 5: Forty-three");
		double Number5 = sc.nextDouble();

		double avg = (Number1 + Number2 + Number3 + Number4 + Number5)/5;

		System.out.println("avg of the numbers: "+avg);

	}
}
