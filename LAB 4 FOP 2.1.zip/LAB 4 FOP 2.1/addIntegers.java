public class addIntegers{
	public static int addIntegers(int... integers){
    int total = 0;
    for(int i = 0;i < integers.length; i++){
		total += integers[i];
   }
   return total;
}
public static void main(String [] args){

	int [] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
       int total1 = addIntegers(2,1); //prints 3

	   int total2 = addIntegers(3, 4, 2, 1); // prints 10

	   int total3 = addIntegers(3, 4, 0); //prints 7

}
}
