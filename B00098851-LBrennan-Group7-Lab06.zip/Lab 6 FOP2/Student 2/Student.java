public class Student{
	private String name;
	private String studentNumber;
	private int year;
	static int numberOfStudentsCreated;

    //no arguments constructor
	public Student()
	{
	name = "a name:";
	studentNumber = "a student number:";
	year = 1;
	numberOfStudentsCreated++;
    }

    //constructor with 3 parameters to initialise the 3 instance variables
    public Student(String aName, String aStNo, int someYear)
    {
		name = aName;
		studentNumber = aStNo;
		year =someYear;
		numberOfStudentsCreated++;
	}

	//the setters/mutators
	public void setName(String aName)
	{
		name = aName;
    }
      public void setStudentNumber(String aStNum)
      {
		  studentNumber = aStNum;
	  }
	  public void setYear(int someYear)
	  {
		  year = someYear;
      }

      //the getters/accessors
      public String getName()
      {
		  return name;
      }
      public String getStudentNumber()
      {
		  return studentNumber;
       }
       public int getYear()
       {
		   return year;
        }
        //method to print the details of a given Student
        public void printStudentDetails()
        {
			System.out.println("Student Details:" + name + "," + studentNumber + "," + year);
	    }
         /*main method to test and debug */
			public static void main(String [] args)
			{
                //create a student object by using the no-arguments constructor
				Student student1 = new Student();

				//print how many objects have been created so far
				System.out.println(Student.numberOfStudentsCreated);

				//print the details to see if they have changed
				student1.printStudentDetails();

               //create 2 other students using the other constructor
				Student student2 = new Student("Aurelia" ,"B0001200", 3);
				System.out.println(student2.numberOfStudentsCreated);

				Student student3 = new Student("Harry" ,"B0001300", 2);
				System.out.println(student1.numberOfStudentsCreated);

                //print their details
				student2.printStudentDetails();
				student3.printStudentDetails();
			}//end main
		}//end class

