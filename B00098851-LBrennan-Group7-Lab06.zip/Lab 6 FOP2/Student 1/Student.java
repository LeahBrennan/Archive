public class Student {
	private String name;
	private String studentNumber;
	private int year;

	//no arguments constructor
	public Student(){
		name = "a name: ";
		studentNumber = "a student number:";
		year = 1;
	}

	//constructor with 3 parameters to initialise the 3 instance variables
    public Student(String aName, String aStNo, int someYear){
		name = aName;
		studentNumber = aStNo;
		year = someYear;
	}
	/* main method to test and debug */
	public static void main(String[] args){
		//create a student object by using the no-arguments constructor
		Student student1 = new Student();
		//print the details to see if they have changed
		System.out.println(student1.name + "" + student1.studentNumber + "" +student1.year);
		//create 2 other students using the other constructor
		Student student2 = new Student("Aurelia","B0001200", 3);
		Student student3 = new Student("Harry","B0001300", 2);
		//print their details
		System.out.println(student2.name + "" + student2.studentNumber + "" +student2.year);
		System.out.println(student3.name + "" + student3.studentNumber + "" +student3.year);

	}//end main
}//end class