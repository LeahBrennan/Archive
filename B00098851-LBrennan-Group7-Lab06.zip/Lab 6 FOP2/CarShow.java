public class CarShow{
	private String make;
	private String registrationNumber;
	private int enginesize;
	static int detailsofacarinstance;

    //constructor
	public CarShow()
	{
	make = "Car make";
	registrationNumber = "Car reg. number:";
	enginesize = 1;
	detailsofacarinstance++;
    }


    public CarShow(String aMake, String aRegNo, int anenginesize)
    {
		make = aMake;
		registrationNumber = aRegNo;
		enginesize = anenginesize;
		detailsofacarinstance++;
	}

	//the setters/mutators
	public void setMake(String aMake)
	{
		make = aMake;
    }
      public void setRegistrationNumber(String aRegNum)
      {
		  registrationNumber = aRegNum;
	  }
	  public void setenginesize(int anenginesize)
	  {
		  enginesize = anenginesize;
      }

      //the getters/accessors
      public String getMake()
      {
		  return make;
      }
      public String getRegistrationNumber()
      {
		  return registrationNumber;
       }
       public int getenginesize()
       {
		   return enginesize;
        }
        //method to print the details of a given car
        public void printCarDetails()
        {
			System.out.println("Car Details:" + make + "," + registrationNumber + "," + enginesize);
	    }
         /*main method to test and debug */
			public static void main(String [] args)
			{
                //car object using the no-arguments constructor
				car car1 = new car("FIAT", "13DL12367",1);

                //print the details 2 other cars using the other constructor
				car car2 = new car("BMW" ,"12D12345", 3);
				car car3 = new car("VOLKSWAGEN" ,"07D453535", 2);

				//print how many objects have been created so far
				System.out.println(car.detailsofacarinstance);

                //correct the engine size of the BMW
                 car2.set("BMW", "12D12345", 3);

                 //redisplay the list
                 car1.printCarDetails();
                 car2.printCarDetails();
                 car3.printCarDetails();
                 System.out.println(car1.detailsofacarinstance);
                 System.out.println(car2.detailsofacarinstance);

                 //remove the third car from the list due to its purchase.
                 car3.remove("VOLKSWAGEN" ,"07D453535", 2);

                 System.out.println(car1.detailsofacarinstance);
                 System.out.println(car2.detailsofacarinstance);

                //print the remaining cars details
                  car1.printCarDetails();
				  car2.printCarDetails();

			}//end main
		}//end class