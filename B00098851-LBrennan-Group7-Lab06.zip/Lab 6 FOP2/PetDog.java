public class PetDog{
	private String breed;
	private String temperament;
	private int AKCrating;
	static int popularityofpet;

    //constructor
	public PetDog()
	{
	breed = "Breed";
	temperament = "Temperament/Personality";
	AKCrating = 1;
	popularityofpet++;
    }


    public PetDog(String aBreed, String aTemper, int aAKCRating)
    {
		breed = aBreed;
		temperament = aTemper;
		AKCrating = aAKCRating;
		popularityofpet++;
	}

	//the setters/mutators
	public void setBreed(String aBreed)
	{
		breed = aBreed;
    }
      public void settemperament(String aTemper)
      {
		  temperament = aTemper;
	  }
	  public void setAKCrating(int aAKCRating)
	  {
		  AKCrating = aAKCRating;
      }

      //the getters/accessors
      public String getBreed()
      {
		  return breed;
      }
      public String getTemperament()
      {
		  return temperament;
       }
       public int getAKCRating()
       {
		   return AKCrating;
        }
        //method to print the details of a given car
        public void printDogDetails()
        {
			System.out.println("Dog Details:" + breed + "," + temperament + "," + AKCrating);
	    }
         /*main method to test and debug */
			public static void main(String [] args)
			{
                //car object using the no-arguments constructor
				PetDog breed1 = new PetDog("Bichon Frise", "Affectionate",1);

				//print how many objects have been created so far
				System.out.println(PetDog.popularityofpet);

				//print the details to see if they have changed
				breed1.printDogDetails();

               //print the details 2 other breeds using the other constructor
				PetDog breed2 = new PetDog("Yorkshire Terrier" ,"Intelligent", 3);
				System.out.println(PetDog.popularityofpet);

				PetDog breed3 = new PetDog("Jack Russell Terrier" ,"Not recommended for a household with small children", 2);
				System.out.println(PetDog.popularityofpet);

                //print their details
                breed1.printDogDetails();
				breed2.printDogDetails();
				breed3.printDogDetails();
			}//end main
		}//end class