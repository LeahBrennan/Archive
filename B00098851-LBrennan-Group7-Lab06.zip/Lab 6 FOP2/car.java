public class car{
	private String make;
	private String registrationNumber;
	private int enginesize;
	static int detailsofacarinstance;

    //constructor
	public car()
	{
	make = "Car make";
	registrationNumber = "Car reg. number:";
	enginesize = 1;
	detailsofacarinstance++;
    }


    public car(String aMake, String aRegNo, int anenginesize)
    {
		make = aMake;
		registrationNumber = aRegNo;
		enginesize = anenginesize;
		detailsofacarinstance++;
	}

	//the setters/mutators
	public void setMake(String aMake)
	{
		make = aMake;
    }
      public void setRegistrationNumber(String aRegNum)
      {
		  registrationNumber = aRegNum;
	  }
	  public void setenginesize(int anenginesize)
	  {
		  enginesize = anenginesize;
      }

      //the getters/accessors
      public String getMake()
      {
		  return make;
      }
      public String getRegistrationNumber()
      {
		  return registrationNumber;
       }
       public int getenginesize()
       {
		   return enginesize;
        }
        //method to print the details of a given car
        public void printCarDetails()
        {
			System.out.println("Car Details:" + make + "," + registrationNumber + "," + enginesize);
	    }
         /*main method to test and debug */
			public static void main(String [] args)
			{
                //car object using the no-arguments constructor
				car car1 = new car("FIAT", "13DL12367",1);

				//print how many objects have been created so far
				System.out.println(car.detailsofacarinstance);

				//print the details to see if they have changed
				car1.printCarDetails();

               //print the details 2 other cars using the other constructor
				car car2 = new car("BMW" ,"12D12345", 3);
				System.out.println(car2.detailsofacarinstance);

				car car3 = new car("VOLKSWAGEN" ,"07D453535", 2);
				System.out.println(car1.detailsofacarinstance);

                //print their details
                car1.printCarDetails();
				car2.printCarDetails();
				car3.printCarDetails();
			}//end main
		}//end class

