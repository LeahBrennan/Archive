import java.util.ArrayList;
     public class ArrayListShop{
		 public static void main(String[] args)
		 {
			 //create an empty list
			 ArrayList<String> shop = new ArrayList<>();
			 System.out.println("Size of list of products before adding any items: " + shop.size()); //size is 0
			 //add some items
			 shop.add("eggs");
			 shop.add("oranges");
			 shop.add("smoked ham");
			 shop.add("bread");
			 shop.add("lettuce");
			 //prints the contents of the list and its size
			 System.out.println("Products list: " + shop);
			 shop.remove("smoked ham");

             shop.add("cured ham");
             System.out.println("New Products List: " + shop);
			 System.out.println("New Products list: " + shop);
			 shop.remove("oranges");

			 System.out.println("Products list: " +shop);


			 shop.add(0, "Broccoli");
			 System.out.println("After adding the new product,the list is: " + shop);

		 }
	 }