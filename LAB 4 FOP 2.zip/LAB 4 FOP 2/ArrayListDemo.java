/*** @author Aurelia Power
     copied from Lecture 4 Powerpoint Feb. 28th 2017
     */
     import java.util.ArrayList;
     public class ArrayListDemo{
		 public static void main(String[] args)
		 {
			 //create an empty list
			 ArrayList<String> friends = new ArrayList<>();
			 System.out.println("Size of friends list before adding any people: " + friends.size()); //size is 0
			 //add some friends
			 friends.add("John");
			 friends.add("Helen");
			 friends.add("Garry");
			 //prints the contents of the list and its size
			 System.out.println("Friends list (so far....): " + friends);

			 System.out.println("Friends list after adding John, Helen, Garry: " + friends.size());//3

			 friends.add(0, "Brendan NewBestFriend");
			 System.out.println("After adding the new best friend, my list is: " + friends);
			 System.out.println("Size of friends list is now: " + friends.size());//4
		 }
	 }