
     import java.util.ArrayList;
     public class ExerciseFour{
		 public static ArrayList<String> letterC(ArrayList<String> list)
		 {
			 //create an empty list
			 ArrayList<String> names = new ArrayList<>();
			 ArrayList<String> letterC = new ArrayList<>();
			 String choose = "c";
			     names.add("annabelle");
			     names.add("barney");
			     names.add("ciara");
			     names.add("cian");
			     names.add("claire");
			     names.add("zelda");
			     names.add("louise");
			     names.add("charmian");
			     for(int i = 0; i<names.size(); i++) {
			         if(names.get(i).startsWith(choose.toUpperCase())) {
			             letterC.add(names.get(i));
			         }
			         if(names.get(i).startsWith(choose)) {
			             letterC.add(names.get(i));
			         }
			     }
			     if(letterC.size() >= 1) {
			         letterC.remove(1);
			         letterC.remove(letterC.size() - 1);
			     }
			     return letterC;
}
      public static ArrayList<Integer> numbers(int n)
	  {
	  ArrayList<Integer> number = new ArrayList<Integer>();

	  if (n <= 0) // The smallest list we can make

	  {
	      return number;
	  }
	  else // All other size lists are created here
	  {
	  }
	  return number;
	  }
   public static void main(String[] args)
   {
	    {
	            ArrayList<Integer> number = new ArrayList<Integer>();
	            if(number.size() == 0)
	            {
	            System.out.println("The list is empty.");
	            }
	            else
	            {
	                for(Integer i: number)
	                {
	                    System.out.println(i);
	                }
	            }
	        }
}
{

        System.out.println("Names beginning with C: ");

	 }
 }