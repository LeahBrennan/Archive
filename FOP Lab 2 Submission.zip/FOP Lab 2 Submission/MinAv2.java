import java.util.Scanner;
public class MinAv2 {

  public static void main(String args[]){
	System.out.println("Numbers: ");
    int arr[] = new int[10];
    Scanner sc = new Scanner(System.in);


    System.out.println(average(arr));//get the Average.

    System.out.println(minimum(arr));//get the minimum value
  }


  public static double average(int[] arr){
   double sum = 0;

      for(int i = 0; i < arr.length; i++)//fill the array with values
      {
		  sum = sum + arr[i];
	  }

    double result = sum / arr.length;
    System.out.println(result);

    return result;


  }

  public static int minimum(int[] arr){
    int minimum = arr[0];//0 is the index
    for (int i = 1; i< arr.length; i++)//fill the array with values
{
	if (arr[i] < minimum)//compares numbers in the index to find the smallest.
	{
		minimum = arr[i];
	}
}
    return minimum;
  }
}