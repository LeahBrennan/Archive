public class proneg
{
  public static void main( String [] args )
  {

    int [] intArray = {};
    int [] negative = {};

    System.out.print( "The elements are " );
    for ( int i = 0; i < intArray.length; i++ )//fill the array with values/
       System.out.print(intArray[i] + " " );
    System.out.println( );

    System.out.println( "The product of all elements in the array is "
                         + arrayProduct( intArray ) );
  }


  public static int arrayProduct(int[] intArray){
      int rtn=1;
      for(int i: intArray){
          rtn*=i;
      }
      return rtn;
}

	 public static int negativenum(int[] array) {

        int negative = 0;
        for (int i = 0; i < array.length; i++)
        {
            if(array[i] < 0){
                negative = negative + 1;
            }
            System.out.println("The number of negative elements in this array are:" +negative);
}
	return negative;


}
}
