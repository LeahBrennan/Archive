public class ex5
{
	public static void main(String[] args)
	{
		//declare a 2D String Array.
		String[][] stringArray ={
		{"Hello", "world"},
		{"How", "Are", "you"},
		{"AC", "BV", "DDA"},
		{"AC", "BV", "DDA", "XYZ"},
		{"AC", "BV", "DDA", "XYZ"}
		};


		//Outer elements
		for(int i = 0; i < stringArray.length; i++)
		{

			//each element of the rows.
			//start at last index
			for(int j = stringArray.length - 1; j >= 0; j--)
			    {
                 System.out.println("" +stringArray[i][j]);
				}


}
}
}
//Compiling successfully, returning a exception in main thread error when attempting to run.




