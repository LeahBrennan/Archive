public class randamach {

public static void main(String[] args){

int [] myArray = {};

//to work out an even integer
for(int i= 0; i< myArray.length; i+=2)

//to work out an odd integer
for(int j= 0; j< myArray.length; j+=2)
{
	 if(myArray[i]%2==0)
	 {
		 System.out.println(myArray[i]+ "");
	 }
 }
}
}