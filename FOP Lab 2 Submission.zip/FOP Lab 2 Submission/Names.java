import java.util.Scanner;

public class Names {

public static void main(String[] args) throws Exception{
    Scanner sc = new Scanner(System.in);

    System.out.println("Enter 10 names: ");
    String n = sc.nextLine();


    String [] names = {n};

    //store the names in an array
    for (int i = 0; i < 10; i++){
        names[i] = sc.nextLine();
        }

    for (int i = 0; i < 5; i = i +1){
        System.out.println("");

        }

    sc.close();

}

}