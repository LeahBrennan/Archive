import java.io.RandomAccessFile;
import java.io.IOException;
import java.util.Random;

public class Ex4{

/**method that allows us to read a random file from start to finish */
public static void readRAFForward(String fileName){
	//open a random access file in read mode only
	try(RandomAccessFile raf = new RandomAccessFile(fileName, "r")) {
		/* get the number of integers using ths size of the file in
		*  bytes divided by 4 to get the number of integers in the file;
		*  remember: there are 4 bytes in an integer (or 32 bits) */
		long numofDoubles = raf.length()/4;
		for(long k = 0; k < numofDoubles; k++){
			double number = raf.readDouble();
			System.out.printf("%d" , number);
		}
	}catch(IOException e){
		System.out.println("Error occured while reading the file...");
	}
}//end of readRAFForward
}