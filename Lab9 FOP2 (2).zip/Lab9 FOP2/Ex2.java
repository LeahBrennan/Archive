import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Ex2 {
	public static void main(String[] args)
	{

	/* use a try-with-resources to open the resources; if the file does
	  * not already exist, it will be automatically created */

	  //Scanner class is used as input will be taken from the user
	try(Scanner sc = new Scanner(System.in);

            //evens.dat
            FileOutputStream evenOut = new FileOutputStream ("evens.dat");
	        DataOutputStream evenWriter = new DataOutputStream(evenOut);

            //odds.dat
	        FileOutputStream  oddOut = new FileOutputStream("odds.dat");
	        DataOutputStream  oddWriter = new DataOutputStream(oddOut);){



				/*use a for loop to access each element of the array and write it
				* to the file by invoking the writeInt method*/
				for(int i = 0; i < 10; i++)
				{
				System.out.println("Enter any integer: ");
				int userInput = sc.nextInt();

				if(userInput % 2 == 0)
				   evenWriter.writeInt(userInput);
				else
				   oddWriter.writeInt(userInput);
			   }
		   }catch(IOException e){
			   e.printStackTrace();
		   }
		   System.out.println("The results are: ");
	   }

   }

