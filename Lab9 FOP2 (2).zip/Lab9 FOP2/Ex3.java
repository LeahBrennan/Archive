import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class Ex3 {
	public static void main(String[] args)
	{

	/* use a try-with-resources to open the resources; if the file does
	  * not already exist, it will be automatically created */
	  //Scanner class is used as input will be taken from the user.
	try(Scanner sc = new Scanner(System.in);

            //evens.dat
            FileInputStream evenIn = new FileInputStream ("evens.dat");
	        DataInputStream evenReader = new DataInputStream(evenIn);

            //odds.dat
	        FileInputStream  oddIn = new FileInputStream("odds.dat");
	        DataInputStream  oddReader = new DataInputStream(oddIn);)
	        {

				/*use a for loop to access each element of the array and write it
				* to the file by invoking the writeInt method*/
				for(int i = 0; i < 100; i++)
				{
				System.out.println("Enter any integer: ");
				int userInput = sc.nextInt();

				if(userInput % 2 == 0)
				   evenReader.readInt();
				else
				   oddReader.readInt();
			   }
		   }catch(IOException e){
			   e.printStackTrace();
		   }

		   System.out.println("The results are:");
	   }
   }

