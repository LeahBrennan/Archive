import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;
/**
* @author Aurelia Power
*
*/
public class WriteToBinaryFileSequentially2 {

	public static void main(String[] args){

	/* use a try-with-resources to open the resources; if the file does
	  * not already exist, it will be automatically created */

	try(FileOutputStream out = new FileOutputStream("chars.dat");

	        DataOutputStream data = new DataOutputStream(out);){

				//declare a random objext that will allow us to create random integers

				Random rand = new Random();

				/* generate 10 random integers between 32 and 126 and then convert them
				* to char (using the cast operator; remember the ASCII table contains
				* characters represented as positive integers between 32 and 126); then
				* write each char to the file invoking the method writeChar */
				for(int i = 0; i < 10; i++){

					char c = (char)(rand.nextInt(95) +32);

					data.writeChar(c);
				}
			}catch(IOException ioe){
				ioe.printStackTrace();
			}
		}//end main
	}//end class