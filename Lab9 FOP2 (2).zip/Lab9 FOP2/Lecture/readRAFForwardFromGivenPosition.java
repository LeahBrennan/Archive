import java.io.RandomAccessFile;
import java.io.IOException;
import java.util.Random;

public class readRAFForwardFromGivenPosition{
/** method that allows us to read a random file forward from a given position */
public static void readRAFForwardFromGivenPosition(String fileName, long position)
{
	//open a random access file in read mode only
	try(RandomAccessFile raf = new RandomAccessFile(fileName, "r")){
		/* get the number of integers using the size of the file in
		* bytes divided by 4 to get the number of integers in the file;
		* remember: there are 4 bytes in an integer (or 32 bits) */
		long numOfInts = raf.length()/4;
		//ensure that the position is not smaller than zero, nor greater than numOfInts -1
		if(position < 0 || position > numOfInts - 1){
			System.out.println("Invalid integer position/index");
			return;//simply return control to the calling method, not a value
		}
		for(long k = position; k < numOfInts; k++){
			//set the file pointer to the given position
			raf.seek(k * 4);
			//use the method readInt to read the integers from the file
			int number = raf.readInt();
			System.out.printf("%d", number);
		}
	}catch(IOException e){
		System.out.println("Error occured while reading the file...");
	}
}//end readRAFForwardFromGivenPosition
}//end class