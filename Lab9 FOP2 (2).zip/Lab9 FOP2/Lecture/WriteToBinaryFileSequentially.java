import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
/**
* @author Aurelia Power
*
*/
public class WriteToBinaryFileSequentially {
	public static void main(String[] args){
	/* use a try-with-resources to open the resources; if the file does
	  * not already exist, it will be automatically created */
	try(FileOutputStream out = new FileOutputStream("ints.dat");
	        DataOutputStream data = new DataOutputStream(out);){
				//declare the array of integers

				int[] ints = {7, 34,25,1,16,10,19};

				/*use a for loop to access each element of the array and write it
				* to the file by invoking the writeInt method*/
				for(int i = 0; i < ints.length; i++){
					data.writeInt(ints[i]);
				}
			}catch(IOException ioe){
				ioe.printStackTrace();
			}
		}//end main
	}//end class