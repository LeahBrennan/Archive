import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
/**
* @author Aurelia Power
*
*/
public class ReadBinaryFileSequentially {
	public static void main(String[] args){
	/* use a try-with-resources to open the file and the read stream;
	this will ensure that they are closed automatically when finished*/
	try(FileInputStream input = new FileInputStream("charList.dat");
	        DataInputStream data = new DataInputStream(input);){
				/*as long as there is data available in the data strem,
				read it using the corresponding method for that data type,
				in our case char, and print it to the console using the print statement */
				while(data.available() > 0){
					System.out.print(data.readChar() + "");
				}
			}catch(IOException ioe){
				ioe.printStackTrace();
			}
		}//end main
	}//end class