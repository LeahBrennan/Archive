public class Person{
	//instance variable
	private int age;
	//constructor

	public Person(int ageIn) {
		if(ageIn >=0) {
			age = ageIn;
		}
	}
	//the setter
	public void setAge(int newAge){
		if (newAge >= 0) {
			age = newAge;
		}
	}
	//the getter
	public int getAge(){
		return age;
	}
	// print the persons details to the console
	public void printPersonDetails(){
		System.out.println("Person's age:" + age);
	}

public static void main(String[] args){
	Person mum = new Person(34);
	System.out.println(mum.getAge());

	Person dad = new Person(-37);
	System.out.println(dad.getAge());

	dad.setAge(37);
	dad.printPersonDetails();

	Person baby = new Person(0);
	System.out.println(baby.getAge());
}
}