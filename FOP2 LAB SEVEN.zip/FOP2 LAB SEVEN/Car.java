public class Car{
	//the instance variables/attributes
	private String make;
	private String regNo;
	private double engSize;


	//2 overloaded constructors
	public Car(){
		make = "A make";
		regNo = "A registration number:";
		engSize = 0.0;
	}
	public Car(String aMake, String aRegNo, double anEngSize){
		if(!aMake.equals(""))
		make = aMake;
		else
		    make = "Some make";
		if(!aRegNo.equals(""))
		regNo = aRegNo;
		else
		   regNo = "A registration number";
		if(anEngSize >= 0.1 && anEngSize <= 7)
		   engSize = anEngSize;
		 else
		     engSize = 0.1;
	}

	// setters
	public void setMake(String aMake) {
		if(!aMake.equals(""))
		make = aMake;
		else
		   make = "A make";

		}
	public void setRegNo(String aRegNo){
		if(!aRegNo. equals(""))
		regNo = aRegNo;
		else
		regNo ="A registration number";
		}
	public void setEngSize(double anEngSize){
		if(anEngSize >= 0.1 && anEngSize <= 7)
		engSize = anEngSize;
		else
		    engSize = 0.1;
		    }

	//getters
	public String getMake(){
		return make;
		}
	public String getRegNo(){
		return regNo;
		}
	public double getEngSize(){
		return engSize;
		}

	//method to print details
	public void printCarDetails(){
		System.out.println(make + "," + regNo + "," + engSize);
	}
	public static void main(String[] args) {
	//create a car object named car1
	Car car1 = new Car("Mazda", "132MH3444", 1.2);
	//print the details of car1
	car1.printCarDetails();
	//change the engine size of car1
	car1.setEngSize(7.5);
	//change the registration number of car 1
	car1.setRegNo("");
	//change the make to Nissan
	car1.setMake("Nissan");
	//re-print the values of car1 after the changes have been made
	System.out.println("Car1 after changing all three details:");
	car1.printCarDetails();

    System.out.println();
	//create another Car object named car 2
	Car car2 = new Car("Toyota", "162D25",1.6);
	//print the details of car2 before making changes to the values
	System.out.println("Car2 before value-changes:");
	car2.printCarDetails();
	//change the make of car2 using an empty string
	car2.setMake("");
	//change the engine size of car2 using a negative value
	car2.setEngSize(-1.2);
	//change the registration to 161 D 1234
	car2.setRegNo("161 D 1234");
	//print the details of car2 again
	System.out.println("Car2 after changes:");
	car2.printCarDetails();
}
}

