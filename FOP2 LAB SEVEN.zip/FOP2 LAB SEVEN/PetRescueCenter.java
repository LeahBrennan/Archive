public class PetRescueCenter{
	//the instance variables/attributes
	private String Breed;
	private String Temperament;
	private String OtherAnimalsChildren;
	private String TimeinCenter;
	private String Adoption;



	//2 overloaded constructors
	public PetRescueCenter(){
		Breed = "Breed";
		Temperament = "The breed's personality attributes: ";
        OtherAnimalsChildren = "Its suitability for a household with other pets and/or children:";
        TimeinCenter = "The time the pet has spent in the center:";
        Adoption = "Reasons you should adopt";
	}
	public PetRescueCenter (String aBreed, String aTemperament, String aOtherAnimalsChildren, String aTimeinCenter, String anAdoption){
			Breed = aBreed;
			Temperament = aTemperament;
	        OtherAnimalsChildren = aOtherAnimalsChildren;
	        TimeinCenter = aTimeinCenter;
            Adoption = anAdoption;
}

	// setters
	public void setBreed(String aBreed) {Breed = aBreed;}
	public void setTemperament(String aTemperament){Temperament = aTemperament;}
	public void setOtherAnimalsChildren(String aOtherAnimalsChildren){OtherAnimalsChildren = aOtherAnimalsChildren;}
	public void setTimeinCenter(String aTimeinCenter){TimeinCenter = aTimeinCenter;}
    public void setAdoption(String anAdoption){Adoption = anAdoption;}

	//getters
	public String getBreed(){return Breed;}
	public String getTemperament(){return Temperament;}
	public String getOtherAnimalsChildren(){return OtherAnimalsChildren;}
	public String getTimeinCenter(){return TimeinCenter;}
	public String getAdoption(){return Adoption;}

	//method to print details
	public void printPetRescueCenterDetails(){
		System.out.println(Breed + "," + Temperament + "," + OtherAnimalsChildren + "," + TimeinCenter + "" + Adoption + "");
	}
	public static void main(String[] args) {
		//create a list to hold Pet object references
		ArrayList<PetRescueCenter> pets = new ArrayList<>();
		//create 5 new objects and add the previously created Pet objects to the list
		PetRescueCenter pet1 = new PetRescueCenter("Bichon", "Affectionate", "Cats: with training, Young children: not recommended", "Two months", "Look down");
		PetRescueCenter pet2 = new PetRescueCenter("Yorkshire Terrier", "Intelligent", "Recommended with training and hard work", "Four months", "I would be great addition to your household");
		PetRescueCenter pet3 = new PetRescueCenter("Jack Russell Terrier", "Energetic", "Recommended under supervision", "Six months", "I would be a good companion");
		PetRescueCenter pet4 = new PetRescueCenter("Labrador","Even Tempered", "Recommended", "Two weeks", "");
		PetRescueCenter pet5 = new PetRescueCenter("American Pitbull Terrier", "Obedient", "Not recommended", "One-year", "I am not like other dogs in my breed");

	    pets.add(pet1);
	    pets.add(pet2);
	    pets.add(pet3);
	    pets.add(pet4);
	    pets.add(pet5);

	   //display each pet details
	     for(int i =0; i < pets.size(); i++){
			 pets.get(i).printPetRescueCenterDetails();
	 }
		 System.out.println();
		 //change the temperament of pet 1
		 pet1.setTemperament("Sensitive");
		 //redisplay the list
		 for(int i = 0; i < pets.size(); i++){
			 pets.get(i).printPetRescueCenterDetails();
	   }
	     //change the other animals, children recommendation of the Jack Russell
	     pet3.setOtherAnimalsChildren("At the owners disgression");

	     //redisplay the list
	     for(int i = 0; i < pets.size(); i++){
			 pets.get(i).printPetRescueCenterDetails();
	 }
	 //remove three of the dogs from the list using the int index method from the Array class and redisplay the list.
	 System.out.println();
	 pets.remove(0);
	 pets.remove(3);
	 pets.remove(4);

	 for(int i = 0; i < pets.size(); i++){
		 pets.get(i).printPetRescueCenterDetails();

}
}
}


