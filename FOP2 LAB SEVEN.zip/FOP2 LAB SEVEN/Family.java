public class Family{
	//instance variable
	private int age;
	//constructor

	public Family(int ageIn) {
		if(ageIn >=0) {
			age = ageIn;
		}
	}
	//the setter
	public void setAge(int newAge){
		if (newAge >= 0) {
			age = newAge;
		}
	}
	//the getter
	public int getAge(){
		return age;
	}
	// print the persons details to the console
	public void printPersonDetails(){
		System.out.println("Person's age:" + age);
	}

public static void main(String[] args){
	Family mum = new Family(34);
	System.out.println(mum.getAge());

	Family dad = new Family(-37);
	System.out.println(dad.getAge());

	dad.setAge(37);
	dad.printPersonDetails();

	Family baby = new Family(0);
	System.out.println(baby.getAge());
}
}