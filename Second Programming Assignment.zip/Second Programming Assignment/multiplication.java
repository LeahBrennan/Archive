import java.util.Scanner;

public class multiplication {

public static void main(String[] args)
{
Scanner sc = new Scanner(System.in);

 int A = 7;

 System.out.println("A: 7");

 int B = 11;

 System.out.println("B: 11");

 int C = A * B;

 System.out.println("C: A x B");


 System.out.println("C: " +C);



}

}
