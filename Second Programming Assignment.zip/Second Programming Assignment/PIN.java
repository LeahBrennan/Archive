import java.util.Scanner;
public class PIN {

    public static void main(String[] args) {

        String pin1, pin2;
        pin1 = "1234";
        pin2 = "9182";

        Scanner input=new Scanner(System.in);
        {
			System.out.println("Please enter the last two pin numbers you can remember");
		}

        System.out.print("Please enter the first pin: ");
        pin1=input.nextLine();
        System.out.print("Please enter the second pin: ");
        pin2=input.nextLine();
        { System.out.println("9182 is correct");
	}
}
}
