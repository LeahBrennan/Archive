import java.util.Scanner;
public class dictionaryorder {

    public static void main(String[] args) {

        String word1, word2;
        word1 = "help";
        word2 = "hello";

        Scanner input=new Scanner(System.in);
        {
			System.out.println("Please enter help and hello");
		}

        System.out.print("Please enter the first word: ");
        word1=input.nextLine();
        System.out.print("Please enter the second word: ");
        word2=input.nextLine();
        { System.out.println("Alphabetically hello comes first");
	}
}
}




