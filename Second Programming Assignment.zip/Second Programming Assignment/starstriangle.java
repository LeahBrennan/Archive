public class starstriangle
  {
	  public static void main(String[] args)
	  {
		  drawStars();

		  System.out.println("");

		  drawStars();

		  System.out.println("");
	  }
	  public static void drawStars(){
		  for (int i=1; i<10; i += 2)
		  {
		      for (int j=0; j<i; j++)
		      {
		          System.out.print("*");
		      }
		      System.out.println("");
}
}
}