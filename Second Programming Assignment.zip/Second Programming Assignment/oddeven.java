import java.util.Scanner;

public class oddeven {

	public static void main(String[] args)
	{
		int x;

		System.out.println("Enter an integer to check if it is odd or even: ");

		Scanner in = new Scanner(System.in);

		x = in.nextInt();

		if( x % 2 == 0)
		System.out.println("You have entered an even number.");

		else
		System.out.println("You have entered an odd number.");
	}
}