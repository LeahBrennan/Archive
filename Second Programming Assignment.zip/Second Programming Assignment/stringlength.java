public class stringlength{

   public static void main(String args[])
   {
       String str1= new String("Apples");

       String str2= new String("Oranges");

       String str3= new String("Pears");

       String str4= new String("Plums");

       System.out.println("Length of str1: 6");

       System.out.println("Length of str2: 7");

       { System.out.println("Oranges is longer then Apples");
   };
        System.out.println("Length of str3: 5");

        System.out.println("Length of str4: 5");

       { System.out.println("Pears and Plums are the same length");
   };
}
}
