import java.util.Scanner;
public class passwordcheck {

    public static void main(String[] args) {

        String pword1, pword2;
        pword1 = "topSecr3t";
        pword2 = "qwert";

        Scanner input=new Scanner(System.in);
        {
			System.out.println("Please enter the last two passwords you can remember");
		}

        System.out.print("Please enter the first password: ");
        pword1=input.nextLine();
        System.out.print("Please enter the second password: ");
        pword2=input.nextLine();
        { System.out.println("topSecr3t is correct");
	}
}
}
