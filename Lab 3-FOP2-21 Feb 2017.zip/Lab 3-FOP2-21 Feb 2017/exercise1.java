public class exercise1{
	public static void main(String[] args)
	{
		int i, j, k, l, m, temp, index, smallerNumber;
		int [] array = {};
		int [] array1 ={};
		String[] array2 ={};
		String key1;

		        bubbleSortAscending(array);
				System.out.print("Organisation through Bubble-Sorting:");
				for(int element: array)
				System.out.print(element);

				System.out.println();

				SelectionSortAscending(array1);
				System.out.print("Organisation through Selection-Sorting:");
				for(int element: array1)
				System.out.print(element);

			    System.out.println();

			    System.out.println("Linear Searching: " + linearSearch(array2, key1));
}// end main method


		 public static int bubbleSortAscending(int[] array){
		    for (int i = 0; i < array.length - 1; i++)
		    for (int j = 0; i < array.length - i- 1; j++) {
		        if (arr[j] > array[j+1])
		        {
		           int temp = array[j];
		           array[j] = arr[j+1];
		           array[j+1] = temp;
		        }//end if
		      }//end inner for
		    }//end outer for
		}//end method bubble sort

    public static int selectionSortingAscending(int[] array1){

	for(int k = 0; k < array1.length - 1; k++)
	{
		int index = k;
		for(int l = k + 1; k < array1.length; k++)
		if (array1[] < array1[index])
		index =l;

		int smallerNumber = array1[index];
		array1[index] = array1[k];
		array1[k] = smallerNumber;
	}

}//end method selection sorting
public static int linearSearch(String [] array2, String key1) {

    for (int m  = 0; m < array2.length; m++)
    {
      if (array2[m].equals(key1))
      return m;

   }
  return -1;
  }//end method linear search

}
}//end class





