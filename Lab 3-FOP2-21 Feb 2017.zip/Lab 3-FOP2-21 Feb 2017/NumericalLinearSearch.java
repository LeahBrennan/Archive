
import java.util.Scanner;

public class NumericalLinearSearch
{
  public static void main(String args[])
  {
    int i,n, key1, array1[];
    double j,k, key2, array2[];

    Scanner in = new Scanner(System.in);
    System.out.println("Enter number of integers: ");
    System.out.println("Enter number of doubles: ");
    i = in.nextInt();
    n = in.nextInt();
    l = in.nextDouble();
    j = in.nextDouble();
    k = in.nextDouble();
    array = new int[i];

    System.out.println("Enter " + n + " integers");
    System.out.println("Enter" + l + "doubles");

    for (i = 0; i < n; i++)
      array1[n] = in.nextInt();

    System.out.println("Enter value to find");
    key = in.nextInt();
}
public static int linearSearch(int [] array1, int key1) {


    for (int i  = 0; i < array.length; i++)
    {
      if (array1[i].equals(key1))
      return i;

   }
  return -1;
  }//end method
}
public static double linearSearch2(double[] array2, double key2){
	for (double j = 0; j < array2.length; j++)
	{
		if(array2[j].equals(key2))
		return j;
	}
	return -1;
}//end method
}