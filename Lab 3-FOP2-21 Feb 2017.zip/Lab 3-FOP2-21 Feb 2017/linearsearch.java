/**
linear search for String array method
*@param array, key
*@return int value
*/


import java.util.Scanner;

public class linearsearch
{
  public static void main(String args[])
  {
    int i,n, key, array[];

    Scanner in = new Scanner(System.in);
    System.out.println("Enter number of integers: ");
    i = in.nextInt();
    n = in.nextInt();
    array = new int[i];

    System.out.println("Enter " + n + " integers");

    for (i = 0; i < n; i++)
      array[n] = in.nextInt();

    System.out.println("Enter value to find");
    key = in.nextInt();
}
public static int linearSearch(String [] array, String key) {


    for (int i  = 0; i < array.length; i++)
    {
      if (array[i].equals(key))
      return i;

   }
  return -1;
  }//end method
}