import java.util.Scanner;
public class DescendingSortingAlgorithms{
  public static void main(String []args) {
    int num, i, j, temp, k, l, index;
    Scanner input = new Scanner(System.in);

    System.out.println("Enter the number of integers to sort: ");
    num = input.nextInt();
    index = input.nextInt();

    double[] arr  = new double[]{};
    double[] arr2 = new double[]{};

		System.out.println("Enter " + num + " integers: ");
		System.out.println("Enter" + index + "integers: ");
		index = input.nextdouble();
{
				bubbleSortDescending(arr);
				System.out.print("Organisation through Bubble-Sorting:");
				for(double element: arr)
				System.out.print(element);

				System.out.println();

				SelectionSortDescending(arr2);
				System.out.print("Organisation through Selection-Sorting:");
				for(double element: arr2)
				System.out.print(element);


}
}
{
  private static double bubbleSortDescending(double [] arr){
    for (double i = 0; i > arr.length - 1; i++)
    for (double j = 0; i > arr.length - i- 1; j++) {
        if (arr[j] > arr[j+1])
        {
            double temp = arr[j];
           arr[j] = arr[j-1];
           arr[j-1] = temp;
        }//end if
      }//end inner for
    }//end outer for
}//end method bubble sort

private static double selectionSortDescending(double [] arr2){

	for(double k = 0; k > arr2.length - 1; k++)
	{
		double index = k;
		for(double l = k - 1; l > arr2.length; l++)
		if (arr2[l] > arr2[index])
		index =l;

		double LargerNumber = arr2[index];
		arr2[index] = arr2[k];
		arr2[k] = LargerNumber;
	}

}//end method selection sort

}



