import java.util.Scanner;
public class bsortasc{
  public static void main(String []args) {
    int num, i, j, temp;
    Scanner input = new Scanner(System.in);

    System.out.println("Enter the number of integers to sort: ");
    num = input.nextInt();

    int[] arr  = new int[]{};

		System.out.println("Enter " + num + " integers: ");


}
  public static void bubbleSortAscending(int[] arr){
    for (int i = 0; i< arr.length - 1; i++)
    for (int j = 0; i < arr.length - i- 1; j++) {
        if (arr[j] > arr[j+1])
        {
           int temp = arr[j];
           arr[j] = arr[j+1];
           arr[j+1] = temp;
        }//end if
      }//end inner for
    }//end outer for
}//end method

