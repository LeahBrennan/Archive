import java.util.Scanner;
public class telephone {
       public static void main (String[] args){

		   Scanner input = new Scanner(System.in);

	         System.out.println("Please enter an area code in words:");
             String x = input.nextLine();

             getCountyForCode(int code);
		 }


            public static String getCountyforCode(int code)
            {

             switch(code)
             {
				 case "One": System.out.println("Dublin");
				 break;

				 case "Twenty-one": System.out.println("Cork");
				 break;

                 case "Forty-four": System.out.println("Westmeath");
                 break;

                 case "Seventy-four":System.out.println("Donegal");
                 break;

                 default: System.out.println("That is incorrect, please try again");
                 break;
}
              return code;

	 }
}

