
     import java.util.ArrayList;
     public class ExerciseFour{
		 public static ArrayList<String> letterC(ArrayList<String> list)
		 {
			 //create an empty list
			 ArrayList<String> names = new ArrayList<>();
			 ArrayList<String> letterC = new ArrayList<>();
			 String choose = "C";
			     names.add("Annabelle");
			     names.add("Barney");
			     names.add("Ciara");
			     names.add("Cian");
			     names.add("Claire");
			     names.add("Zelda");
			     names.add("Louise");
			     names.add("Charmian");
			     for(int i = 0; i<names.size(); i++) {
			         if(names.get(i).startsWith(choose.toUpperCase())) {
			             letterC.add(names.get(i));
			         }
			         if(names.get(i).startsWith(choose)) {
			             letterC.add(names.get(i));
			         }
			     }
			     if(letterC.size() >= 1) {
			         letterC.remove(1);
			         letterC.remove(letterC.size() - 1);
			     }
			     return letterC;
}
      public static ArrayList<Integer> number(int n)
	  {
	  ArrayList<Integer> number = new ArrayList<Integer>();
	   number.add(20);
	   number.add(20);
	   number.add(20);
	   number.add(20);


	  if (n < 100)

	  {
	      System.out.println("Please add another value");
	      number.add(20);
       }

	  else
	  {
	  }
	  return number;
	  }
   public static void main(String[] args)
   {

	    {
	            ArrayList<Integer> number = new ArrayList<Integer>();
	            if(number.size() == 0)
	            {
	            System.out.println("All values add up to 100");
	            }
	            else
	            {
	                for(Integer i: number)
	                {
	                    System.out.println("The list is empty");
	                }
	            }
	        }

 String choose = "C";
    if (choose.equals("C")){
      String choice = "C";
      ArrayList<String> list;
      System.out.println("The names beginning with C are: Ciara, Cian and Charmian ");

	 }
 }
}