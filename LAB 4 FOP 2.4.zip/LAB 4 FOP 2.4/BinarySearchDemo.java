/** method that implements the binary search for an int array */
public class BinarySearchDemo{
		public static int binarySearchc(char [] data, char key)
	    {
	    int low = 0;
		int high = data.length - 1;
		//initialise the search boundaries to the end indices of the array data.

		while(high >= low) {
			int middle = (low + high) / 2;
			//compute the middle index

			if(data[middle] == key) {
				return middle;
				//if the element at middle index matches the key, return the middle index
			}// end if
			if(data[middle] < key) {
				low = middle + 1;
				//if the element at middle index is smaller than the key, update the lower bound so we will look only at the second half.
			}//end if
			if(data[middle] > key){
				high = middle -1;
				//if the element at middle index is greater than the key, update the upper bound so we will look only at the first half.
			}//end if
		}//end while
		return -1;
		// if we no longer can split the halves into further halves , return -1, because that value does not exist in the array.
	}//end method binary searchc


	/**
	@param args: main method to test the binarySearch method
	*/
	public static void main(String [] args){

        char[] arr = {'a', 'b', 'c', 'd', 'e', 'f', 'h', 'j'};

        int e = binarySearchc(arr, 'g');
        System.out.println((e != -1) ? ("Key found at index" + e) :"key not found");

        e = binarySearchc(arr, 'b');
        System.out.println((e != -1) ? ("Key found at index" + e ) :"key not found");



	}//end main method
}//end class
