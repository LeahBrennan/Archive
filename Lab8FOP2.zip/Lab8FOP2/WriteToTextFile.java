import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
/**
*@author Aurelia Power
*
*/
  public class WriteToTextFile {
	  public static void main(String[] args) {
		  //declare the array of names that you want to write to a file
		  String[] names = {"Aurelia", "Arthur", "Elena", "John", "Luca", "Maria", "Michael"};
		  //the file that you want to write to
		  File namesFile = new File("names.txt");
		  //open resources in a try
		  try(FileWriter writer = new FileWriter(namesFile);
		             BufferedWriter bufferW = new BufferedWriter(writer)){
                         //use a for loop to go through each element of the array
						for(int i = 0; i < names.length; i++){
							//write each element of the array(the names) to the file
							//using one of the overloaded write methods
							bufferW.write(names[i] + "");
					}

				    }catch(IOException e)
				    {

						e.printStackTrace();
					}//end catch
				}//end main

			}//end class


