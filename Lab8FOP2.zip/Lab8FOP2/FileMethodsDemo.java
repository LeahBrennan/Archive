import java.io.File;
/**
* @author Aurelia Power
*
*/
public class FileMethodsDemo{
public static void main(String[] args) {
		//create the file object using the full path and name of the file
		File file = new File("C:\\Users\\Aurelia Power\\Desktop\\files\\names.txt");

		//check to see whether the file exists on your computer
		System.out.println(file.exists());//true on my computer

		//check to see if it is directory
		System.out.println(file.isDirectory());//fales, because it is not a folder

		//check to see if it is a file
		System.out.println(file.isFile());//true, because it is a file

		//retrieve the absolute path of the file
		System.out.println(file.getAbsolutePath());//C:\Users\Aurelia Power\Desktop\names.txt

		//set permissions so you can only read it in this program
		//we cannot write to it or modify its content in this program
		file.setReadOnly();

		//check to see if you can write to it/modify its contents
		System.out.println(file.canWrite());//false

}//end main
}//end class