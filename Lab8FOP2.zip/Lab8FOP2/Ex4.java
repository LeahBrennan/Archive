import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
/**
*@author Leah
*
*/
  public class Ex4
  {
	  public static void main(String[] args)
	  {
		  File file = new File("integers.txt");
		  try(FileReader reader = new FileReader(file);
		             BufferedReader bufferR = new BufferedReader(reader)){
						 String line = "";
						 while((line = bufferR.readLine()) != null)
				      {
							 System.out.println(line);
					  }
					  /*int ch = 0;
					  while((ch = bufferR.read())!= -1)
					  {
						  System.out.print((char)ch);
					  }*/
				  }
				    catch(IOException e)
				    {
						System.out.println("Error...");
						//e.printStackTrace();
					}
				}
			}