import java.io.File;
/**
* @author Leah Brennan
*
*/
public class Ex3{
	public static void main(String[] args) {
		//create the file object using the full path and name of the file
		File file = new File("C:\\Users\\B00098851\\Desktop\\Lab8FOP2\\integers.txt");

		//check to see whether the file exists on your computer
		System.out.println(file.exists());//true on my computer

		//check to see if it is directory
		System.out.println(file.isDirectory());//fales, because it is not a folder

		//retrieve the absolute path of the file
		System.out.println(file.getPath());//C:\\Users\\B00098851\\Desktop\\Lab8FOP2\\integers.txt

		//set permissions so you can only read it in this program
		//we cannot write to it or modify its content in this program
		file.setWritable(true, false);

		//check to see if you can write to it/modify its contents
		System.out.println(file.canWrite());//false

}//end main
}//end class