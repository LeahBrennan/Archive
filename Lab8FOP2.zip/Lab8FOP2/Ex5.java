import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException ;
/**
*@author Aurelia Power
*
*/
  public class Ex5
  {
	  public static void main(String[] args)
	  {
		  //declare the array of names that you want to write to a file
		  String[] numbers = {"14", "16", "25", "19", "7", "10", "28" };

		  File numbersFile = new File("integers.txt");
		  try(FileWriter writer = new FileWriter(numbersFile);
		             BufferedWriter bufferW = new BufferedWriter(writer)){

						for(int i = 0; i < numbers.length; i++){
							bufferW.write(numbers[i] + "");
						}

				    }catch(IOException e)
				    {

						e.printStackTrace();
					}
				}
			}
			//ADD COMMENTS AND FIX
